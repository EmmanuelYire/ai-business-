# FinWise Financial — Career Venture Lab

A simulated investment-advisory business dashboard built with Flask, SQLite, HTML, CSS, and JavaScript.

## What the app does

- Displays simulated revenue, operating expenses, profit, margin, and break-even subscribers.
- Lets the team change business assumptions and recalculate the model.
- Shows a six-month illustrative forecast and revenue-mix chart.
- Manages a sample client/prospect pipeline.
- Records and removes sample operating expenses.
- Exports a CSV financial report.
- Provides rule-based educational decision prompts.

## Important classroom-use note

FinWise Financial is a fictional business. All sample customers, prices, costs, forecasts, and financial results are invented for this school project. The app is an educational business simulation, not a real investment adviser, broker, bank, or financial institution. It does not connect to investment accounts, trade securities, recommend particular investments, or provide personalized financial advice. Do not enter real customer or financial-account information.

## Run locally

Requires Python 3.10 or newer.

```bash
python -m venv .venv
```

Activate the environment:

- Windows PowerShell: `.\.venv\Scripts\Activate.ps1`
- macOS/Linux: `source .venv/bin/activate`

Install and run:

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Publish with GitHub and Render

1. Create a new GitHub repository named `finwise-financial`.
2. Upload the contents of this project folder to the repository (the files should be at the repository root, not inside an extra nested folder).
3. Sign in to Render and choose **New + → Blueprint** or create a **Web Service** connected to the GitHub repository.
4. If using Blueprint, Render reads `render.yaml`. If creating a Web Service manually:
   - Runtime: Python
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
   - Health check path: `/health`
5. Deploy. Render will provide a public URL when the build succeeds.

## Data storage note

The starter app uses SQLite in the app directory. On Render's free web-service filesystem, local files may be temporary and can be reset during redeploys, restarts, or instance replacement. The app is suitable for a classroom demonstration with sample data. For durable multi-user data, connect a managed PostgreSQL database and migrate the app before relying on it.

## Mathematics used

Let:
- `S` = number of monthly subscribers
- `p` = monthly membership price
- `C` = number of advisory service clients per month
- `f` = average advisory service fee
- `F` = fixed monthly operating costs
- `v` = variable cost per subscriber

Revenue:
`R = Sp + Cf`

Variable costs:
`VC = Sv`

Total operating expenses:
`E = F + Sv`

Monthly operating profit:
`P = R - E = Sp + Cf - F - Sv`

Operating margin:
`M = (P / R) × 100%`, when revenue is greater than zero.

Break-even subscriber count, assuming advisory revenue offsets fixed costs:
`S_BE = (F - Cf) / (p - v)`, rounded up to the next whole subscriber, when `p > v`. If advisory revenue already covers fixed costs, the minimum is zero subscribers.

Annualized operating profit is the current monthly profit multiplied by 12. This is a simple run-rate illustration, not a forecast guarantee.

## Suggested class discussion

- Which assumption has the largest effect on profit?
- What happens to break-even subscribers if the membership price falls?
- How does a higher variable cost change contribution per subscriber?
- Why should the team test more than one forecast scenario?
- What risks are not represented in this simplified model?
