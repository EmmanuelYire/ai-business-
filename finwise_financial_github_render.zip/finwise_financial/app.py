from flask import Flask, render_template, request, jsonify
from pathlib import Path
import sqlite3
import os
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("DATABASE_PATH", BASE_DIR / "finwise.db"))
app = Flask(__name__)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS assumptions (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                monthly_subscribers INTEGER NOT NULL,
                monthly_fee REAL NOT NULL,
                consulting_clients INTEGER NOT NULL,
                consulting_fee REAL NOT NULL,
                fixed_costs REAL NOT NULL,
                variable_cost_per_subscriber REAL NOT NULL,
                startup_cost REAL NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                service TEXT NOT NULL,
                monthly_value REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'Active'
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                amount REAL NOT NULL,
                month TEXT NOT NULL
            )
        """)
        row = conn.execute("SELECT id FROM assumptions WHERE id=1").fetchone()
        if not row:
            conn.execute("""INSERT INTO assumptions
                (id, monthly_subscribers, monthly_fee, consulting_clients,
                 consulting_fee, fixed_costs, variable_cost_per_subscriber, startup_cost)
                VALUES (1, 500, 12, 12, 250, 4200, 2.25, 18000)""")
            conn.executemany("""INSERT INTO clients (name, service, monthly_value, status)
                VALUES (?, ?, ?, ?)""", [
                ("Northstar Design Co.", "Small-business financial planning", 450, "Active"),
                ("Harborview Market", "Cash-flow education package", 300, "Active"),
                ("BrightPath Studio", "Budgeting workshop", 200, "Active"),
                ("Oak & Main Services", "Financial literacy subscription", 150, "Prospect"),
            ])
            conn.executemany("""INSERT INTO expenses (category, description, amount, month)
                VALUES (?, ?, ?, ?)""", [
                ("Technology", "Website, software, and hosting", 650, "2026-11"),
                ("Marketing", "Digital campaigns and outreach", 900, "2026-11"),
                ("Payroll", "Part-time operations support", 1900, "2026-11"),
                ("Administration", "Insurance and office costs", 750, "2026-11"),
            ])

def get_assumptions():
    with db() as conn:
        row = conn.execute("SELECT * FROM assumptions WHERE id=1").fetchone()
        return dict(row)

def calculate(a):
    subscribers = max(0, int(a["monthly_subscribers"]))
    sub_fee = max(0, float(a["monthly_fee"]))
    clients = max(0, int(a["consulting_clients"]))
    consulting_fee = max(0, float(a["consulting_fee"]))
    fixed = max(0, float(a["fixed_costs"]))
    variable = max(0, float(a["variable_cost_per_subscriber"]))
    startup = max(0, float(a["startup_cost"]))

    subscription_revenue = subscribers * sub_fee
    consulting_revenue = clients * consulting_fee
    revenue = subscription_revenue + consulting_revenue
    variable_costs = subscribers * variable
    expenses = fixed + variable_costs
    profit = revenue - expenses
    margin = (profit / revenue * 100) if revenue else 0
    contribution_per_subscriber = sub_fee - variable
    break_even_subscribers = None
    if contribution_per_subscriber > 0:
        break_even_subscribers = max(0, int((fixed - consulting_revenue) / contribution_per_subscriber + 0.999999))
    return {
        "subscription_revenue": round(subscription_revenue, 2),
        "consulting_revenue": round(consulting_revenue, 2),
        "revenue": round(revenue, 2),
        "fixed_costs": round(fixed, 2),
        "variable_costs": round(variable_costs, 2),
        "expenses": round(expenses, 2),
        "profit": round(profit, 2),
        "margin": round(margin, 1),
        "break_even_subscribers": break_even_subscribers,
        "startup_cost": round(startup, 2),
        "annualized_profit": round(profit * 12, 2),
    }

@app.route("/")
def home():
    return render_template("index.html")

@app.get("/api/dashboard")
def dashboard():
    a = get_assumptions()
    metrics = calculate(a)
    with db() as conn:
        clients = [dict(r) for r in conn.execute("SELECT * FROM clients ORDER BY id DESC").fetchall()]
        expenses = [dict(r) for r in conn.execute("SELECT * FROM expenses ORDER BY id DESC").fetchall()]
    # Illustrative six-month forecast: subscribers grow 4% monthly, consulting clients 2% monthly.
    forecast = []
    for i, month in enumerate(["Dec", "Jan", "Feb", "Mar", "Apr", "May"], start=1):
        s = int(a["monthly_subscribers"] * (1.04 ** i))
        c = int(a["consulting_clients"] * (1.02 ** i))
        rev = s * a["monthly_fee"] + c * a["consulting_fee"]
        exp = a["fixed_costs"] + s * a["variable_cost_per_subscriber"]
        forecast.append({"month": month, "revenue": round(rev, 2), "expenses": round(exp, 2), "profit": round(rev-exp, 2)})
    return jsonify({"assumptions": a, "metrics": metrics, "clients": clients, "expenses_list": expenses, "forecast": forecast})

@app.post("/api/assumptions")
def update_assumptions():
    data = request.get_json(force=True)
    fields = ["monthly_subscribers", "monthly_fee", "consulting_clients", "consulting_fee",
              "fixed_costs", "variable_cost_per_subscriber", "startup_cost"]
    try:
        values = []
        for field in fields:
            value = float(data[field])
            if value < 0:
                raise ValueError("Values must be zero or greater.")
            if field in ("monthly_subscribers", "consulting_clients"):
                value = int(value)
            values.append(value)
    except (KeyError, TypeError, ValueError) as exc:
        return jsonify({"error": f"Please enter valid non-negative numbers. {exc}"}), 400
    with db() as conn:
        conn.execute("""UPDATE assumptions SET monthly_subscribers=?, monthly_fee=?,
            consulting_clients=?, consulting_fee=?, fixed_costs=?,
            variable_cost_per_subscriber=?, startup_cost=? WHERE id=1""", values)
    return jsonify({"ok": True, "metrics": calculate(get_assumptions())})

@app.post("/api/clients")
def add_client():
    data = request.get_json(force=True)
    name = str(data.get("name", "")).strip()
    service = str(data.get("service", "")).strip()
    try:
        value = float(data.get("monthly_value", 0))
        if not name or not service or value < 0:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify({"error": "Enter a name, service, and non-negative monthly value."}), 400
    with db() as conn:
        conn.execute("INSERT INTO clients (name, service, monthly_value, status) VALUES (?, ?, ?, ?)",
                     (name[:80], service[:120], value, "Prospect"))
    return jsonify({"ok": True})

@app.delete("/api/clients/<int:client_id>")
def delete_client(client_id):
    with db() as conn:
        conn.execute("DELETE FROM clients WHERE id=?", (client_id,))
    return jsonify({"ok": True})

@app.post("/api/expenses")
def add_expense():
    data = request.get_json(force=True)
    category = str(data.get("category", "")).strip()
    description = str(data.get("description", "")).strip()
    month = str(data.get("month", datetime.now().strftime("%Y-%m")))
    try:
        amount = float(data.get("amount", 0))
        datetime.strptime(month, "%Y-%m")
        if not category or not description or amount < 0:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify({"error": "Enter a category, description, valid month, and non-negative amount."}), 400
    with db() as conn:
        conn.execute("INSERT INTO expenses (category, description, amount, month) VALUES (?, ?, ?, ?)",
                     (category[:60], description[:140], amount, month))
        # The expense register is linked to the financial model's fixed-cost total.
        conn.execute("UPDATE assumptions SET fixed_costs = fixed_costs + ? WHERE id=1", (amount,))
    return jsonify({"ok": True})

@app.delete("/api/expenses/<int:expense_id>")
def delete_expense(expense_id):
    with db() as conn:
        row = conn.execute("SELECT amount FROM expenses WHERE id=?", (expense_id,)).fetchone()
        if row:
            conn.execute("UPDATE assumptions SET fixed_costs = MAX(0, fixed_costs - ?) WHERE id=1", (row["amount"],))
            conn.execute("DELETE FROM expenses WHERE id=?", (expense_id,))
    return jsonify({"ok": True})

@app.get("/health")
def health():
    return {"status": "ok", "app": "FinWise Financial"}

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
