const money = n => new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0}).format(Number(n)||0);
const exactMoney = n => new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:2}).format(Number(n)||0);
let dashboardData = null, performanceChart = null, mixChart = null;
const $ = id => document.getElementById(id);
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
async function api(url, options={}){const res=await fetch(url,{headers:{"Content-Type":"application/json"},...options});const data=await res.json();if(!res.ok)throw new Error(data.error||"Something went wrong.");return data}
function updateInsights(m,a){
  let title="Protect your contribution margin", text="Review variable service costs and subscriber retention before increasing marketing spend.";
  if(m.profit<0){title="Prioritize the path to break-even";text="The current model shows an operating loss. Test pricing, fixed costs, and customer volume before expanding."}
  else if(m.margin>35){title="Evaluate sustainable growth";text="The modeled operating margin is positive. Test whether additional marketing or support costs still leave enough contribution."}
  else{text="Compare subscription pricing and variable service costs. Small changes to either can have a meaningful effect as subscribers grow."}
  $("insightTitle").textContent=title;$("insightText").textContent=text;
  $("insightList").innerHTML=[
    "Compare the cost of acquiring subscribers with their expected subscription revenue.",
    "Track advisory capacity so client growth does not reduce service quality.",
    "Keep enough cash available to cover fixed monthly expenses."
  ].map(x=>`<div><span class="check">✓</span><p>${x}</p></div>`).join("");
}
function renderCharts(data){
  const f=data.forecast;
  if(performanceChart)performanceChart.destroy();
  performanceChart=new Chart($("performanceChart"),{type:"line",data:{labels:f.map(x=>x.month),datasets:[
    {label:"Revenue",data:f.map(x=>x.revenue),borderColor:"#27876e",backgroundColor:"#27876e18",fill:true,tension:.35,borderWidth:2,pointRadius:2},
    {label:"Expenses",data:f.map(x=>x.expenses),borderColor:"#efb18e",backgroundColor:"transparent",tension:.35,borderWidth:2,pointRadius:2},
    {label:"Profit",data:f.map(x=>x.profit),borderColor:"#8b82bd",backgroundColor:"transparent",tension:.35,borderWidth:2,pointRadius:2}
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${money(c.raw)}`}}},scales:{x:{grid:{display:false},ticks:{color:"#94a19a",font:{size:9}}},y:{grid:{color:"#edf1ee"},ticks:{color:"#94a19a",font:{size:9},callback:v=>"$"+(v/1000).toFixed(0)+"k"}}}}});
  if(mixChart)mixChart.destroy();
  mixChart=new Chart($("mixChart"),{type:"doughnut",data:{labels:["Memberships","Advisory services"],datasets:[{data:[data.metrics.subscription_revenue,data.metrics.consulting_revenue],backgroundColor:["#27876e","#9d92cf"],borderWidth:0,hoverOffset:4}]},options:{cutout:"76%",responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>`${c.label}: ${money(c.raw)}`}}}}});
}
function renderTables(data){
  $("clientRows").innerHTML=data.clients.map(c=>`<tr><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.service)}</td><td>${money(c.monthly_value)}</td><td><span class="status ${c.status==="Prospect"?"prospect":""}">${c.status}</span></td><td><button class="delete-btn" data-client="${c.id}" title="Remove client">×</button></td></tr>`).join("")||'<tr><td colspan="5">No clients yet.</td></tr>';
  $("expenseRows").innerHTML=data.expenses_list.map(e=>`<tr><td>${escapeHtml(e.category)}</td><td>${escapeHtml(e.description)}</td><td>${money(e.amount)}</td><td><button class="delete-btn" data-expense="${e.id}" title="Remove expense">×</button></td></tr>`).join("")||'<tr><td colspan="4">No expenses yet.</td></tr>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderReport(m){
  $("reportSummary").innerHTML=[
    ["Revenue",money(m.revenue)],["Operating expenses",money(m.expenses)],["Operating profit",money(m.profit)],["Operating margin",m.margin.toFixed(1)+"%"],
  ].map(([a,b])=>`<div class="report-stat"><span>${a}</span><b>${b}</b></div>`).join("")+
  `<div class="report-decision"><b>Decision prompt:</b> ${m.profit>=0?"The current assumptions produce a positive monthly operating result. Before expanding, test a slower subscriber-growth scenario and confirm that the business can cover its fixed costs.":"The current assumptions produce a monthly operating loss. Consider adjusting pricing, customer volume, or costs and recalculate before making an expansion decision."} This is a simulated model, not a prediction.</div>`;
}
function render(data){
  dashboardData=data;const m=data.metrics,a=data.assumptions;
  $("revenue").textContent=money(m.revenue);$("expenses").textContent=money(m.expenses);$("profit").textContent=money(m.profit);
  $("margin").textContent=m.margin.toFixed(1)+"% margin";
  $("breakEven").textContent=m.break_even_subscribers===null?"N/A":m.break_even_subscribers.toLocaleString();
  $("subRevenue").textContent=money(m.subscription_revenue);$("consultRevenue").textContent=money(m.consulting_revenue);
  $("mixTotal").textContent=money(m.revenue);
  const form=$("assumptionForm");Object.keys(a).forEach(k=>{if(form.elements[k])form.elements[k].value=a[k]});
  renderCharts(data);renderTables(data);renderReport(m);updateInsights(m,a);
}
async function refresh(){try{render(await api("/api/dashboard"))}catch(e){toast(e.message)}}
$("assumptionForm").addEventListener("submit",async e=>{e.preventDefault();const payload=Object.fromEntries(new FormData(e.currentTarget).entries());try{await api("/api/assumptions",{method:"POST",body:JSON.stringify(payload)});await refresh();toast("Financial model recalculated.")}catch(err){toast(err.message)}});
$("resetModel").addEventListener("click",async()=>{const defaults={monthly_subscribers:500,monthly_fee:12,consulting_clients:12,consulting_fee:250,fixed_costs:4200,variable_cost_per_subscriber:2.25,startup_cost:18000};try{await api("/api/assumptions",{method:"POST",body:JSON.stringify(defaults)});await refresh();toast("Default assumptions restored.")}catch(e){toast(e.message)}});
$("addClientBtn").addEventListener("click",()=>$("clientDialog").showModal());
$("addExpenseBtn").addEventListener("click",()=>$("expenseDialog").showModal());
$("clientForm").addEventListener("submit",async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());try{await api("/api/clients",{method:"POST",body:JSON.stringify(data)});$("clientDialog").close();e.currentTarget.reset();await refresh();toast("Client added.")}catch(err){toast(err.message)}});
$("expenseForm").addEventListener("submit",async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());try{await api("/api/expenses",{method:"POST",body:JSON.stringify(data)});$("expenseDialog").close();e.currentTarget.reset();await refresh();toast("Expense recorded.")}catch(err){toast(err.message)}});
document.addEventListener("click",async e=>{const c=e.target.closest("[data-client]"),x=e.target.closest("[data-expense]");try{if(c){await api("/api/clients/"+c.dataset.client,{method:"DELETE"});await refresh();toast("Client removed.")}if(x){await api("/api/expenses/"+x.dataset.expense,{method:"DELETE"});await refresh();toast("Expense removed.")}}catch(err){toast(err.message)}});
function downloadReport(){
  if(!dashboardData)return;const m=dashboardData.metrics,a=dashboardData.assumptions;
  const rows=[["FinWise Financial - Simulated Monthly Report"],["Metric","Value"],["Monthly subscribers",a.monthly_subscribers],["Membership fee",a.monthly_fee],["Advisory clients",a.consulting_clients],["Average advisory fee",a.consulting_fee],["Subscription revenue",m.subscription_revenue],["Advisory revenue",m.consulting_revenue],["Total revenue",m.revenue],["Fixed costs",m.fixed_costs],["Variable costs",m.variable_costs],["Total expenses",m.expenses],["Operating profit",m.profit],["Operating margin (%)",m.margin],["Break-even subscribers",m.break_even_subscribers??"N/A"],["Startup cost",m.startup_cost],["Annualized operating profit (run-rate)",m.annualized_profit],[],["Note","All figures are simulated for classroom learning, not investment advice."]];
  const csv=rows.map(r=>r.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\n");
  const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="finwise-monthly-report.csv";a.click();URL.revokeObjectURL(url);toast("CSV report downloaded.");
}
$("exportReport").addEventListener("click",downloadReport);$("exportTop").addEventListener("click",downloadReport);
refresh();
